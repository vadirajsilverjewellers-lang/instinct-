# Instinct AI ಆಪ್ — WhatsApp ಚಾಟ್ ಆಪ್ ಒಳಗೇ

ಈ ಆಪ್ ತೆರೆದರೆ **WhatsApp ಆಪ್‌ಗೆ ಹೋಗದೆ**, ಇದರೊಳಗೇ Instinct ಚಾಟ್ ತೆರೆಯುತ್ತೆ (WhatsApp Web ಬಳಸಿ).

## APK ಪಡೆಯುವುದು
1. github.com → **New repository** → `instinct-app` → Create.
2. **uploading an existing file** → ಈ zip ಒಳಗಿನ ಎಲ್ಲಾ ಫೈಲ್/ಫೋಲ್ಡರ್ (`.github` ಕೂಡ) → Commit.
   - `.github` ಹೋಗದಿದ್ದರೆ: **Add file → Create new file** → ಹೆಸರು `.github/workflows/build-apk.yml` → zip ನಲ್ಲಿರುವ ಅದೇ ಫೈಲ್‌ನ ಬರಹ ಪೇಸ್ಟ್ → Commit.
3. **Actions** → *Build Instinct AI APK* → ✅ ಆದ ಮೇಲೆ **Artifacts → Instinct-AI-APK** ಡೌನ್‌ಲೋಡ್.
4. zip ಒಳಗಿನ `app-debug.apk` ಇನ್‌ಸ್ಟಾಲ್ ಮಾಡಿ.

## ಮೊದಲ ಬಾರಿ (ಒಮ್ಮೆ ಮಾತ್ರ)
1. ಆಪ್ ತೆರೆಯಿರಿ → **Instinct ನಂಬರ್** ಹಾಕಿ (WhatsApp ನಲ್ಲಿ Instinct ಹೆಸರು ಒತ್ತಿದರೆ ನಂಬರ್ ಕಾಣುತ್ತೆ).
2. WhatsApp Web ಲಾಗಿನ್ ಪರದೆ ಬರುತ್ತೆ. ಅಲ್ಲಿ **"Log in with phone number"** ಒತ್ತಿ → ನಿಮ್ಮ ನಂಬರ್ ಹಾಕಿ → **8 ಅಕ್ಷರದ ಕೋಡ್** ಕಾಣುತ್ತೆ.
3. ಈಗ ನಿಜವಾದ **WhatsApp** ಆಪ್ ತೆರೆಯಿರಿ → ⋮ → **Linked devices → Link a device → Link with phone number instead** → ಆ ಕೋಡ್ ಹಾಕಿ.
4. ಮತ್ತೆ Instinct AI ಆಪ್‌ಗೆ ಬನ್ನಿ → ಸೀದಾ Instinct ಚಾಟ್ ತೆರೆಯುತ್ತೆ ✅
5. ಇನ್ನು ಮುಂದೆ ಐಕಾನ್ ಒತ್ತಿದರೆ ನೇರವಾಗಿ Instinct ಚಾಟ್.

## ಬಳಕೆ
- ಟೈಪ್ ಮಾಡಿ, ಫೋಟೋ/ಫೈಲ್ ಕಳಿಸಿ, 🎤 ವಾಯ್ಸ್ ನೋಟ್ ಕಳಿಸಿ (ಮೊದಲ ಬಾರಿ ಮೈಕ್ ಅನುಮತಿ ಕೊಡಿ).
- ಪರದೆ ಚಿಕ್ಕದಾಗಿ ಕಂಡರೆ ಎರಡು ಬೆರಳಿನಿಂದ zoom ಮಾಡಿ.
- **Back** ಬಟನ್ → ಚಾಟ್ ಮತ್ತೆ ತೆರೆಯಿರಿ / ನಂಬರ್ ಬದಲಿಸಿ / ಹೊರಗೆ.

## ಗಮನಿಸಿ
- ಇದು WhatsApp ನ ಅಧಿಕೃತ ಆಪ್ ಅಲ್ಲ; ಒಳಗೆ ಅಧಿಕೃತ WhatsApp Web ತೆರೆಯುತ್ತೆ. WhatsApp Web ಬದಲಾದರೆ ಕೆಲವೊಮ್ಮೆ "browser not supported" ಬರಬಹುದು — ಆಗ ಹೇಳಿ, ಸರಿಪಡಿಸೋಣ.
- ಈ ಆಪ್‌ನಲ್ಲಿ **ನೋಟಿಫಿಕೇಶನ್ ಬರಲ್ಲ** — Instinct ಉತ್ತರ ನೋಡಲು ಆಪ್ ತೆರೆಯಿರಿ (ನಿಜವಾದ WhatsApp ನಲ್ಲೂ ಅದೇ ಮೆಸೇಜ್ ಕಾಣುತ್ತೆ).
- ನಿಮ್ಮ ಮುಖ್ಯ ಫೋನ್‌ನ WhatsApp ಆಗಾಗ ಇಂಟರ್ನೆಟ್‌ಗೆ ಬರುತ್ತಿರಬೇಕು, ಇಲ್ಲದಿದ್ದರೆ ~14 ದಿನದ ನಂತರ ಲಿಂಕ್ ಕಡಿತ ಆಗುತ್ತೆ.
- WhatsApp → Linked devices ನಲ್ಲಿ ಯಾವಾಗ ಬೇಕಾದರೂ ಈ ಆಪ್ ಅನ್ನು **Log out** ಮಾಡಬಹುದು.
