package com.vadiraj.instinct;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Instinct AI — opens the Instinct chat of WhatsApp Web inside this app
 * (no jump to the WhatsApp app). The phone is linked once as a WhatsApp
 * "Linked device"; after that the app opens straight into the Instinct chat.
 */
public class MainActivity extends Activity {
    private static final int REQ_FILE = 2, REQ_MIC = 3;
    private static final String DESKTOP_UA =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    private WebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingPerm;
    private long lastBlock = 0;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("instinct", MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0b0b12"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(DESKTOP_UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handle(r.getUrl());
            }
            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handle(Uri.parse(url));
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                // never let the page hand over to the WhatsApp app
                v.evaluateJavascript("(function(){try{var o=window.open;window.open=function(u){if(u&&!/^https?:/i.test(u))return null;return o.apply(window,arguments)}}catch(e){}})()", null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView v, boolean dialog, boolean user, android.os.Message m) { return false; }
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try { startActivityForResult(p.createIntent(), REQ_FILE); }
                catch (ActivityNotFoundException e) { fileCallback = null; return false; }
                return true;
            }
            @Override
            public void onPermissionRequest(PermissionRequest req) {   // voice notes
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else {
                        pendingPerm = req;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    }
                });
            }
        });

        if (b != null) web.restoreState(b);
        else if (prefs.getString("number", "").isEmpty()) askNumber();
        else openInstinct();
    }

    /** true = we handled it (blocked or sent to browser); false = load inside the app */
    private boolean handle(Uri u) {
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if (scheme.equals("whatsapp") || scheme.equals("intent") || scheme.equals("market")) {
            // page tried to jump to the WhatsApp app -> stay here instead (no loop: plain web home on repeat)
            long now = System.currentTimeMillis();
            if (now - lastBlock < 5000) web.loadUrl("https://web.whatsapp.com/"); else openInstinct();
            lastBlock = now;
            return true;
        }
        if (!scheme.startsWith("http")) return true;              // ignore any other app link
        if (host.equals("wa.me") || host.equals("api.whatsapp.com") || (host.equals("web.whatsapp.com") && u.getPath() != null && u.getPath().startsWith("/send") && u.getQueryParameter("app_absent") == null)) {
            openInstinct();            // force the in-app web version
            return true;
        }
        if (host.endsWith("whatsapp.com") || host.endsWith("whatsapp.net")) return false; // stay inside
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
        return true;                                               // other websites -> browser
    }

    private void openInstinct() {
        String n = prefs.getString("number", "").replaceAll("[^0-9]", "");
        // app_absent=1 tells WhatsApp NOT to open the WhatsApp app
        web.loadUrl("https://web.whatsapp.com/send/?phone=" + n + "&text&type=phone_number&app_absent=1");
    }

    private void askNumber() {
        final EditText in = new EditText(this);
        in.setInputType(InputType.TYPE_CLASS_PHONE);
        in.setHint("+1 555 000 0000");
        in.setText(prefs.getString("number", ""));
        new AlertDialog.Builder(this)
            .setTitle("Instinct WhatsApp ನಂಬರ್")
            .setMessage("ದೇಶದ ಕೋಡ್ ಸಹಿತ Instinct ನಂಬರ್ ಹಾಕಿ")
            .setView(in)
            .setCancelable(false)
            .setPositiveButton("ಸರಿ", (d, w) -> {
                String num = in.getText().toString().trim();
                if (num.replaceAll("[^0-9]", "").length() < 8) { Toast.makeText(this, "ಸರಿಯಾದ ನಂಬರ್ ಹಾಕಿ", Toast.LENGTH_LONG).show(); askNumber(); return; }
                prefs.edit().putString("number", num).apply();
                openInstinct();
            }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        if (req == REQ_MIC && pendingPerm != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) pendingPerm.grant(pendingPerm.getResources());
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setItems(new String[]{"🔄 Instinct ಚಾಟ್ ಮತ್ತೆ ತೆರೆಯಿರಿ", "⚙️ ನಂಬರ್ ಬದಲಿಸಿ", "🚪 ಹೊರಗೆ"}, (d, i) -> {
                if (i == 0) openInstinct();
                else if (i == 1) askNumber();
                else finish();
            }).show();
    }
}
